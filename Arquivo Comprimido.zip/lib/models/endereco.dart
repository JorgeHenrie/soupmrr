class Endereco {
  final String rua;
  final String numero;
  final String bairro;
  final String cep;
  final String municipio;

  Endereco({
    required this.rua,
    required this.numero,
    required this.bairro,
    required this.cep,
    required this.municipio,
  });
}
