import 'package:flutter/material.dart';

import 'package:provider/provider.dart';
import 'package:rhmobile/pages/Declaracoes_irpf_page.dart';
import 'package:rhmobile/pages/auth_or_home.dart';
import 'package:rhmobile/pages/auth_page.dart';
import 'package:rhmobile/pages/configuracoes.dart';
import 'package:rhmobile/pages/home_page.dart';
import 'package:rhmobile/pages/notifications_page.dart';
import 'package:rhmobile/pages/page_militar.dart';
import 'package:rhmobile/pages/plantao_page.dart';
import 'models/auth_model.dart';
import 'utils/app_routes.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      // Cria uma escala de servico com uma data
      create: (_) => Auth(),
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'EuPMRR',
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        //home: HomePage(),
        initialRoute: '/',
        routes: {
          AppRoutes.AUTH_PAGE: (context) => const AuthPage(),
          AppRoutes.AUTH_OR_HOME: (context) => const AuthOrHome(),
          AppRoutes.PAGE_MILITAR: (context) => const PageMilitar(),
          AppRoutes.CONFIGURACOES: (context) => const Configuracoes(),
          AppRoutes.HOME_PAGE: (context) => HomePage(),
          AppRoutes.PLANTAO: (context) => const PlantaoPage(),
          AppRoutes.NOTIFICATIONS_PAGE: (context) => NotificationsPage(),
          AppRoutes.DECLARACOES_IRPF_PAGE: (context) =>
              const DeclaracoesIrpfPage(),

          //ROTA COM DADOS
          // AppRoutes.VISUALIZAR_MILITAR: (context) {
          //   final args = ModalRoute.of(context)?.settings.arguments as Militar;

          //   return ViewMilitarPage(
          //     mil: args,
          //   );
          // },
        },
      ),
    );
  }
}
