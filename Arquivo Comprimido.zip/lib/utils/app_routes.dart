class AppRoutes {
  static const AUTH_PAGE = '/auth-page';
  static const HOME_PAGE = '/home-page';
  static const AUTH_OR_HOME = '/';
  static const PAGE_MILITAR = '/page-militar';
  static const CONFIGURACOES = '/configuracoes';
  static const PLANTAO = '/plantao';
  static const DECLARACOES_IRPF_PAGE = '/declaracoes-irpf-page';
  static const NOTIFICATIONS_PAGE = '/notifications-page';
}
