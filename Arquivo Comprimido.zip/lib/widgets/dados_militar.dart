import 'package:flutter/material.dart';
import 'package:rhmobile/models/militar.dart';
import 'package:rhmobile/widgets/card_image_militar.dart';
import 'package:rhmobile/widgets/dados_contato.dart';
import 'package:rhmobile/widgets/dados_endereco.dart';
import 'package:rhmobile/widgets/dados_principal.dart';

class DadosMilitar extends StatefulWidget {
  final Militar militar;

  const DadosMilitar({Key? key, required this.militar}) : super(key: key);

  @override
  State<DadosMilitar> createState() => _DadosMilitarState();
}

class _DadosMilitarState extends State<DadosMilitar> {
  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;

    return Container(
      width: width,
      height: height,
      decoration: BoxDecoration(color: Colors.white),
      //Coluna central da pagina
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(4.0),
            child: Row(
              children: [
                CardImageMilitar(urlImage: widget.militar.imageUrl),
                SizedBox(width: 10),
                DadosPrincipal(militar: widget.militar),
              ],
            ),
          ),
          SizedBox(height: 1),
          DadosEndereco(militar: widget.militar),
          DadosContato(
            militar: widget.militar,
            atualizarDados: atualizarDados,
          ),
          SizedBox(height: 6),
          widget.militar.alterouDados == true
              ? ElevatedButton(
                  onPressed: () {
                    print('OS DADOS SAO');
                    widget.militar.telefones.forEach((element) {
                      print(
                          'TELEFONE: ${element.numeroTel} TIPO: ${element.tipo}');
                    });
                  },
                  child: Text('Salvar Alterações'),
                  style: ElevatedButton.styleFrom(
                    primary: Colors.blue,
                    onPrimary: Colors.white,
                    shadowColor: Colors.grey,
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.0)),
                    minimumSize: Size(15, 25), //////// HERE
                  ),
                )
              : Container()
        ],
      ),
    );
  }

  atualizarDados() {
    setState(() {});
  }
}
