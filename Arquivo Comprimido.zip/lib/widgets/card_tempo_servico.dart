import 'package:flutter/material.dart';

class CardTempoServico extends StatelessWidget {
  const CardTempoServico({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
        decoration: BoxDecoration(color: Colors.blue),
        child: Text('Tempo de Servico'));
  }
}
