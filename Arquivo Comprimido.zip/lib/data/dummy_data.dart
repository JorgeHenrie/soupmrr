// import 'package:rhmobile/models/endereco.dart';

// import '../models/militar.dart';

// final dummyMilitares = [
//   Militar(
//     matricula: '47001950',
//     postoGraduacao: 'SD',
//     qra: 'Lucas Silva',
//     cpf: '018867868686',
//     nomeCompleto: 'Lucas Sousa da Silva',
//     imageUrl:
//         'https://cdn.pixabay.com/photo/2016/03/31/18/26/coding-1294361_960_720.png',
//     subUnidade: 'teste',
//     endereco: Endereco(
//         bairro: 'Centenario',
//         rua: 'Ravena',
//         numero: '157',
//         cep: '69312655',
//         municipio: 'Boa Vista'),
//   ),
//   Militar(
//     matricula: '47001951',
//     postoGraduacao: 'SD',
//     qra: 'Lucas Silva',
//     cpf: '9079879789798789',
//     nomeCompleto: 'Lucas Sousa da Silva',
//     imageUrl:
//         'https://cdn.pixabay.com/photo/2016/11/15/09/24/builders-1825689__340.jpg',
//     subUnidade: 'teste',
//     endereco: Endereco(
//         bairro: 'Centenario',
//         rua: 'Ravena',
//         numero: '157',
//         cep: '69312655',
//         municipio: 'Boa Vista'),
//   ),
// ];
