import 'package:flutter/material.dart';
import 'package:rhmobile/widgets/drawer_personalizado.dart';

class DeclaracoesIrpfPage extends StatefulWidget {
  const DeclaracoesIrpfPage({Key? key}) : super(key: key);

  @override
  _DeclaracoesIrpfPageState createState() => _DeclaracoesIrpfPageState();
}

class _DeclaracoesIrpfPageState extends State<DeclaracoesIrpfPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Declaracoes IRPF'),
      ),
      body: Container(
        child: Text('Dados Financeiros'),
      ),
      drawer: Drawerpersonalizado(),
    );
  }
}
