import 'package:flutter/material.dart';
import 'package:rhmobile/widgets/drawer_personalizado.dart';

class PlantaoPage extends StatefulWidget {
  const PlantaoPage({Key? key}) : super(key: key);

  @override
  _PlantaoPageState createState() => _PlantaoPageState();
}

class _PlantaoPageState extends State<PlantaoPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Meu Plantao'),
      ),
      body: Container(
        child: Text('Meu Plantao'),
      ),
      drawer: Drawerpersonalizado(),
    );
  }
}
